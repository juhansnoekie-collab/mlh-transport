# MLH Transport Website

A modern, responsive website for MLH Transport, a South African trucking company. The website includes a quote calculator that uses Google Maps to validate addresses and calculate distances.

## Features

- Instant quote calculator with Google Maps integration
- South Africa-specific address autocomplete
- PDF quote generation and sharing via email/WhatsApp
- Secure admin dashboard with authentication
- Quote history and management
- Responsive design for all devices
- ZAR currency with VAT support
- Depot-based pricing with hidden internal calculations

## Technologies Used

- Frontend:
  - React
  - TypeScript
  - Vite
  - Tailwind CSS
  - shadcn/ui components
  - Google Maps API (Places, Distance Matrix)
  - jsPDF for PDF generation

- Backend:
  - Supabase (PostgreSQL, Auth, Edge Functions)
  - Resend (Email API)
  - WhatsApp Cloud API

## Getting Started

See the [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed instructions on:
- Getting a free Google Maps API key
- Deploying the website on your Ubuntu server
- Setting up your domain

## Supabase Setup

1. Create a new Supabase project
2. Run the SQL migrations in the `supabase/migrations` directory
3. Deploy the Edge Functions in the `supabase/functions` directory
4. Set the following secrets for the Edge Functions:
   - `GOOGLE_MAPS_API_KEY`: Your Google Maps API key
   - `RESEND_API_KEY`: Your Resend API key
   - `WHATSAPP_TOKEN`: Your WhatsApp Cloud API token
   - `WHATSAPP_PHONE_ID`: Your WhatsApp phone number ID

## Development

To run the project locally:

```bash
# Install dependencies
npm install

# Start the development server
npm run dev
```

## Building for Production

```bash
# Build the project
npm run build

# Preview the production build
npm run preview
```

## Admin Access

Initial admin users:
- emroc259@gmail.com
- leona951@gmail.com

The default password is set during the first login. To add more admin users, use the Admin Dashboard.

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

## Contact

For any questions or support, please contact MLH Transport.
