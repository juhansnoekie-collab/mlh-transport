#!/bin/bash

# Start the development server on port 12000
npm run dev -- --port 12000 --host 0.0.0.0