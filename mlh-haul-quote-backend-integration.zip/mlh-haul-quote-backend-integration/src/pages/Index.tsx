import QuoteCalculator from '@/components/QuoteCalculator';
import heroImage from '@/assets/hero-mlh.jpg';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(180deg,hsl(var(--brand)/.08),transparent_50%,hsl(var(--brand)/.08))]" aria-hidden="true" />
        <section className="container py-16 md:py-24 grid gap-10 md:grid-cols-2 items-center">
          <div className="space-y-5">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">MLH Transport — Reliable Truck Hire in South Africa</h1>
            <p className="text-lg text-muted-foreground">Instant quotes in ZAR with VAT, verified by Google Maps. Transparent pricing. Professional drivers.</p>
            <div className="flex gap-3">
              <a href="#quote" className="inline-block"><span className="sr-only">Skip to quote</span></a>
              <a href="/admin" className="text-sm underline underline-offset-4">Admin</a>
            </div>
          </div>
          <div className="relative rounded-xl overflow-hidden shadow-[var(--shadow-elegant)]">
            <img src={heroImage} alt="MLH Transport truck driving through South Africa" loading="lazy" className="w-full h-full object-cover" />
          </div>
        </section>
      </header>

      <main className="container pb-20">
        <section className="py-4" id="quote">
          <QuoteCalculator />
        </section>
      </main>

      <footer className="border-t">
        <div className="container py-8 text-sm text-muted-foreground flex items-center justify-between">
          <span>© {new Date().getFullYear()} MLH Transport</span>
          <a href="/admin" className="hover:underline">Admin Dashboard</a>
        </div>
      </footer>
    </div>
  );
};

export default Index;
