import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '@/components/auth/LoginForm';
import { useAuth } from '@/contexts/AuthContext';

const Login: React.FC = () => {
  const { user, adminUser, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user && adminUser) {
      navigate('/admin');
    }
  }, [user, adminUser, loading, navigate]);

  return (
    <main className="container py-10 min-h-screen flex flex-col items-center justify-center">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold">MLH Transport</h1>
        <p className="text-muted-foreground">Admin Dashboard Login</p>
      </div>
      <LoginForm />
    </main>
  );
};

export default Login;